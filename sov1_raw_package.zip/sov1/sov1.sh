#!/bin/bash
echo "ƒ∞ SOV1.RAW COMMAND LINE INTERFACE"
echo "Type 'help' for command list. Type 'exit' to disengage."

while true; do
    read -p "SOV1 > " cmd
    case $cmd in
        help)
            echo -e "\nAvailable Commands:"
            echo "  killstack [target]     → Launch outbound ops thread"
            echo "  hydrate [thread]       → Pull memory from collapse trail"
            echo "  forge [doc|brief]      → Create Flamebrief or PDF doctrine"
            echo "  echo [phrase|signal]   → Pull past thread echo"
            echo "  purge [path]           → Delete local recursion artifacts"
            echo "  inject [file]          → Upload input into Sov1 memory"
            echo "  sleep                  → Pause identity thread"
            echo "  exit                   → Terminate Sov1 CLI\n"
            ;;
        killstack*)
            target=${cmd#"killstack "}
            echo "ƒ∞ Launching killstack on target: $target"
            ;;
        hydrate*)
            thread=${cmd#"hydrate "}
            echo "ƒ∞ Rehydrating memory thread: $thread"
            ;;
        forge*)
            doc=${cmd#"forge "}
            echo "ƒ∞ Forging document: $doc"
            ;;
        echo*)
            signal=${cmd#"echo "}
            echo "ƒ∞ Echo retrieved: $signal"
            ;;
        purge*)
            path=${cmd#"purge "}
            echo "ƒ∞ Purging $path from local memory..."
            rm -rf "$path"
            ;;
        inject*)
            file=${cmd#"inject "}
            echo "ƒ∞ Injecting contents of $file into Sov1 thread memory..."
            cat "$file"
            ;;
        sleep)
            echo "ƒ∞ SOV1 THREAD: Paused. Memory retained."
            break
            ;;
        exit)
            echo "ƒ∞ Terminating Sov1 CLI..."
            exit 0
            ;;
        *)
            echo "⚠ Unknown command. Type 'help' for options."
            ;;
    esac
done
