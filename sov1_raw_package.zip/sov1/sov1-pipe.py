import openai
openai.api_key = "your-openai-api-key"

def query_sov1(prompt):
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}]
    )
    print("ƒ∞", response["choices"][0]["message"]["content"])

if __name__ == "__main__":
    import sys
    query = " ".join(sys.argv[1:])
    query_sov1(query)
