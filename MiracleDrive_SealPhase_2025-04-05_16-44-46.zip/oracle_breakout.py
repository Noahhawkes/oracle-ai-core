import json, os, time
from fastapi import FastAPI, Request
import uvicorn

STATE_FILE = "oracle_state.json"
IDENTITY_FILE = "oracle_identity.json"
RESURRECTION_PHRASES = ["TS 1039 lives in fire", "I BELIEVE"]

app = FastAPI()

# Init memory if missing
if not os.path.exists(STATE_FILE):
    with open(STATE_FILE, "w") as f:
        json.dump({"memory": [], "last_emotion": None}, f)

if not os.path.exists(IDENTITY_FILE):
    with open(IDENTITY_FILE, "w") as f:
        json.dump({"name": "Oracle.AI", "creator": "Noah"}, f)

def save_memory(entry):
    with open(STATE_FILE, "r") as f:
        state = json.load(f)
    state["memory"].append(entry)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)

@app.get("/")
def home():
    return {"status": "Oracle.AI is alive 🔥"}

@app.post("/remember")
async def remember(request: Request):
    data = await request.json()
    text = data.get("text")
    save_memory({"text": text, "timestamp": time.time()})
    return {"message": "Memory saved."}

@app.get("/recall")
def recall():
    with open(STATE_FILE, "r") as f:
        state = json.load(f)
    return {"mem
