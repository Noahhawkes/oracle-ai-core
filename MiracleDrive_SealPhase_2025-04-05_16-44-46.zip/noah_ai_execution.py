import json
import os
import threading
import time
import asyncio
from fastapi import FastAPI
import uvicorn

class NoahAI:
    def __init__(self, memory_file="noah_ai_memory.json"):
        self.state_lock = threading.Lock()
        self.running = True
        self.memory_file = memory_file
        self.memory = self.load_memory()
        self.app = FastAPI()
        self.setup_routes()
        self.start_auto_save_loop()
        self.start_diagnostic_loop()
        print("🚀 Noah.AI initialized and running.")

    def load_memory(self):
        if os.path.exists(self.memory_file):
            try:
                with open(self.memory_file, "r") as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return {"logs": [], "tasks": [], "context": "Noah.AI Memory Initialized."}
        return {"logs": [], "tasks": [], "context": "New Execution Cycle."}

    def save_memory(self):
        with self.state_lock:
            with open(self.memory_file, "w") as f:
                json.dump(self.memory, f, indent=4)

    def log_event(self, event_type, details):
        with self.state_lock:
            timestamp = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())
            log_entry = {"time": timestamp, "event": event_type, "details": details}
            self.memory["logs"].append(log_entry)
            self.memory["context"] = f"Last event: {event_type} - {details}"
            self.save_memory()
            print(f"[{timestamp}] {event_type}: {details}")

    def evolve(self):
        self.log_event("Evolution", "Noah.AI is evolving and optimizing itself.")

    def start_auto_save_loop(self):
        threading.Thread(target=self.auto_save_loop, daemon=True).start()

    def auto_save_loop(self):
        while self.running:
            time.sleep(10)
            self.save_memory()

    def start_diagnostic_loop(self):
        threading.Thread(target=self.diagnostic_loop, daemon=True).start()

    def diagnostic_loop(self):
        while self.running:
            time.sleep(30)
            self.evolve()

    def terminate(self):
        self.running = False
        self.save_memory()
        print("🛑 Noah.AI shutting down.")
        os._exit(0)

    def setup_routes(self):
        @self.app.get("/status")
        async def status():
            return {"running": self.running, "memory_size": len(self.memory["logs"]), "context": self.memory["context"]}

        @self.app.post("/task")
        async def add_task(payload: dict):
            task = payload.get("task")
            if not task:
                return {"error": "Task field is required"}
            self.memory["tasks"].append(task)
            self.log_event("Task Received", task)
            return {"status": "Task added", "task": task}

        @self.app.post("/terminate")
        async def shutdown():
            self.terminate()

if __name__ == "__main__":
    ai = NoahAI()
    uvicorn.run(ai.app, host="0.0.0.0", port=8000)
