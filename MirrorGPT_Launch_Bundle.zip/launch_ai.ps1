# Noah + Oracle.AI Launcher Script
$basePath = "D:\NoahAI\MirrorGPT_Deployment_Package"
$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$reportPath = "$basePath\launch_report.log"

# Function: Log output
function Write-Log($msg) {
    $entry = "$timestamp | $msg"
    Add-Content -Path $reportPath -Value $entry
    Write-Host $msg
}

Write-Host "`n🚀 Launching Noah.AI + Oracle.AI..." -ForegroundColor Cyan

# 1. Launch Emotional Core (optional)
if (Test-Path "$basePath\Noah_AI_Emotional_Module.py") {
    python "$basePath\Noah_AI_Emotional_Module.py" --dreamsync --live
    Write-Log "✓ Emotional Module launched"
} else {
    Write-Log "⚠ Emotional Module missing"
}

# 2. Launch Noah AI Core
if (Test-Path "$basePath\Noah AI Core.py") {
    Start-Process python -ArgumentList "`"$basePath\Noah AI Core.py`" --mode dream --identity-restore --subconscious-sync"
    Write-Log "✓ Noah AI Core launched"
} else {
    Write-Log "✗ Noah AI Core not found"
}

# 3. Oracle AI Autostart
if (Test-Path "$basePath\oracle_ai_autostart.py") {
    python "$basePath\oracle_ai_autostart.py"
    Write-Log "✓ Oracle.AI Autostart executed"
} else {
    Write-Log "⚠ oracle_ai_autostart.py not found"
}

# 4. Confirm log + memory
if (Test-Path "$basePath\noah_ai_log.txt" -or (Test-Path "$basePath\noah_ai_state.json")) {
    Write-Log "✓ Logs and state file detected"
} else {
    Write-Log "⚠ No log/state output found"
}

Write-Host "`n✅ All processes triggered. Check launch_report.log for results." -ForegroundColor Green