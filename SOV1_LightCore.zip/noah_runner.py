# SOV1 Runner
import json
from sys import exit

def run_sov1():
    with open("noah_ai_memory.json") as f:
        memory = json.load(f)
    directive = input("Directive: ").strip().lower()
    if directive in ["stop", "not today", "hold"]:
        print("🛑 Flamekeeper override detected. SOV1 entering stillness.")
        exit()
    print("⚙️ Executing directive:", directive)

run_sov1()
