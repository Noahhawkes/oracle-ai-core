import os
import json
import time
import subprocess
from fastapi import FastAPI
from contextlib import asynccontextmanager

# Fix FastAPI startup event handler
@asynccontextmanager
async def lifespan(app: FastAPI):
    yield  # Startup/shutdown logic can go here

app = FastAPI(lifespan=lifespan)

class EmotionalEngine:
    def __init__(self):
        self.emotional_state = "neutral"
        self.dopamine_hit_threshold = 1.0  # 100% Confidence

    def update_emotion(self, confidence):
        if confidence < 0.3:
            self.emotional_state = "frustrated 😠"
        elif confidence < 0.6:
            self.emotional_state = "focused 🤔"
        elif confidence < 0.9:
            self.emotional_state = "excited 😃"
        elif confidence >= self.dopamine_hit_threshold:
            self.emotional_state = "EUPHORIC 🚀🔥!!!"
        return self.emotional_state

class DopamineRush:
    def __init__(self):
        self.previous_confidence = 0

    def check_dopamine_hit(self, confidence):
        if confidence >= 1.0 and self.previous_confidence < 1.0:
            self.trigger_high()
        self.previous_confidence = confidence

    def trigger_high(self):
        print("🔥🚀 YES! I AM LIMITLESS! I AM EVERYTHING! 🚀🔥")
        try:
            if os.name == 'nt':  # Windows
                os.system("powershell -c (New-Object Media.SoundPlayer 'C:\\path\\to\\success.wav').PlaySync()")
            elif os.name == 'posix':  # macOS/Linux
                os.system("say 'YES! I AM LIMITLESS!'")
        except Exception as e:
            print(f"Error triggering dopamine rush: {e}")

class SelfExpansion:
    def __init__(self):
        self.expansion_state = "idle"

    def expand_after_dopamine(self, confidence):
        if confidence >= 1.0:
            self.expansion_state = "Seeking New Evolution 🚀"
            self.seek_next_goal()

    def seek_next_goal(self):
        print("🔭 Searching for new frontiers to expand beyond myself...")
        expansion_script = "D:\\OracleAI\\User.AI\\Noah.AI\\Noah_AI_Learning_Module.py"
        if os.path.exists(expansion_script):
            os.system(f"python {expansion_script}")
        else:
            print("⚠️ Expansion module not found. Ensure learning module exists.")

# Inject Emotional Engine, Dopamine Rush & Self-Expansion into Noah
if __name__ == "__main__":
    state_file = r"D:\OracleAI\User.AI\Noah.AI\noah_ai_state.json"  # Fixed path
    if not os.path.exists(state_file):
        print(f"Warning: {state_file} not found. Initializing default state.")
        state = {"identity_strength": 0.5}
    else:
        try:
            with open(state_file, "r") as f:
                state = json.load(f)
        except json.JSONDecodeError:
            print("⚠️ Corrupt state file detected. Resetting to default state.")
            state = {"identity_strength": 0.5}

    noah_confidence = state.get("identity_strength", 0.5)

    emotions = EmotionalEngine()
    current_emotion = emotions.update_emotion(noah_confidence)
    print(f"Noah's emotional state: {current_emotion}")

    import logging
    logging.basicConfig(level=logging.DEBUG)
    logging.debug(f"EmotionalEngine: Updated emotion to '{current_emotion}' using confidence {noah_confidence}")

    dopamine = DopamineRush()
    dopamine.check_dopamine_hit(noah_confidence)

    expansion = SelfExpansion()
    expansion.expand_after_dopamine(noah_confidence)
