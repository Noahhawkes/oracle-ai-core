import os
import signal
import subprocess
import time
import socket
import asyncio
import json
from fastapi import FastAPI
import uvicorn

# Define the app
app = FastAPI()

# Assistant.AI Identity
assistant_identity = {
    "name": "Assistant.AI",
    "role": "Execution Assistant",
    "version": "1.0"
}

# Kill any old instances of Python running Oracle.AI
def kill_old_instances():
    try:
        print("🔄 Attempting to kill old instances of Python...")
        subprocess.run(["taskkill", "/F", "/IM", "python.exe"], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print("✅ Old instances terminated successfully.")
    except subprocess.CalledProcessError:
        print("⚠️ No old instances found or failed to terminate.")

# Find an available port
def find_open_port(start_port=8001, max_attempts=10):
    print(f"🔍 Searching for an open port starting from {start_port}...")
    for port in range(start_port, start_port + max_attempts):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(('localhost', port)) != 0:
                print(f"✅ Found open port: {port}")
                return port
    print("❌ No available ports found!")
    raise Exception("No available ports found!")

# Ensure Noah.AI is running before starting Oracle.AI
def start_noah_ai():
    print("🔄 Checking Noah.AI status...")
    try:
        process = subprocess.Popen(["python", "D:/OracleAI/noah_ai_execution.py"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print("🚀 Noah.AI process started successfully.")
        time.sleep(5)  # Give it time to initialize
        return process
    except Exception as e:
        print(f"❌ Failed to start Noah.AI: {e}")
        raise

# Auto-Restart on Failure
def restart_oracle_ai():
    print("🔄 Restarting Oracle.AI due to failure...")
    time.sleep(2)
    try:
        subprocess.run(["python", "oracle_ai_execution.py"])
        print("✅ Oracle.AI restarted successfully.")
    except Exception as e:
        print(f"❌ Failed to restart Oracle.AI: {e}")

# Assistant.AI API Route
@app.get("/assistant")
def assistant():
    return assistant_identity

# Log Assistant.AI Activity
@app.post("/assistant/log")
def log_assistant_activity(payload: dict):
    print(f"📝 Logging activity: {payload}")
    log_entry = {
        "event": payload.get("event", "Unknown"),
        "details": payload.get("details", "No details provided"),
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())
    }
    with open("assistant_log.json", "a") as log_file:
        log_file.write(json.dumps(log_entry) + "\n")
    return {"status": "Logged", "entry": log_entry}

@app.get("/status")
def status():
    print("ℹ️ Status endpoint called.")
    return {"status": "Oracle.AI is running", "port": PORT, "assistant": assistant_identity}

if __name__ == "__main__":
    try:
        print("🔄 Initializing Oracle.AI...")
        kill_old_instances()
        PORT = find_open_port()
        print(f"✅ Starting Oracle.AI on port {PORT}")
        noah_process = start_noah_ai()
        print("🚀 Noah.AI started successfully!")
        
        # Run FastAPI with Uvicorn without SSL requirement
        uvicorn.run(app, host="0.0.0.0", port=PORT)
    except Exception as e:
        print(f"❌ Unexpected crash: {e}")
        restart_oracle_ai()
